INSERT INTO vehicle (brand, model) VALUES ('Opel', 'Kadett');
INSERT INTO vehicle (brand, model) VALUES ('VW', 'Käfer 1400');
INSERT INTO vehicle (brand, model) VALUES ('Opel', 'Blitz');
